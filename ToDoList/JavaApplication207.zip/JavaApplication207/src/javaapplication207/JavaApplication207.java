/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication207;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author leocastillo
 */
public class JavaApplication207 {

    public static void main(String[] args) throws FileNotFoundException {
        // Declaring variables
        String userName, password, email;
        boolean b = false;

        /*
       * Creating an Scanner class object which is used to get the inputs
       * entered by the user
         */
        Scanner sc = new Scanner(System.in);

        //Getting the input entered by the user
        System.out.print("Enter user name :");
        userName = sc.nextLine();
        while (true) {
            //Getting the input entered by the user
            System.out.print("\nEnter password :");
            password = sc.nextLine();
            b = isValidpassword(password);
            if (b) {
                break;
            }
        }

        while (true) {
            //Getting the input entered by the user
            System.out.print("\nEnter E-mail :");
            email = sc.nextLine();

            b = isValidEmail(email);
            if (!b) {
                System.out.println("E-mail already exists.Choose another one");
            } else {
                break;
            }
        }
        System.out.println("You have created an account successfully!");

    }

    // This method wil check whether the email is valid or not
    private static boolean isValidEmail(String email) throws FileNotFoundException {
        String s = "";
        Scanner readFile = new Scanner(new File("emaildata.txt"));
        while (readFile.hasNextLine()) {
            s = readFile.nextLine();
            if (s.equalsIgnoreCase(email)) {
                return false;
            }
        }
        return true;
    }

    // This method wil check whether the password is valid or not
    private static boolean isValidpassword(String password) {
        int upperCnt = 0, lowerCnt = 0, digitCnt = 0, specialCnt = 0;
        for (int i = 0; i < password.length(); i++) {
            if (Character.isLowerCase(password.charAt(i))) {
                lowerCnt++;
            }
            if (Character.isUpperCase(password.charAt(i))) {
                upperCnt++;
            }
            if (Character.isDigit(password.charAt(i))) {
                digitCnt++;
            }
            if ((password.charAt(i) == '!') || (password.charAt(i) == '@') || (password.charAt(i) == '#')
                    || (password.charAt(i) == '$')) {
                specialCnt++;
            }
        }
        if (upperCnt == 0) {
            System.out.println("Password must contain atleast 1 uppercase letter");
        }
        if (lowerCnt == 0) {
            System.out.println("Password must contain atleast 1 lowercase letter");
        }
        if (digitCnt == 0) {
            System.out.println("Password must contain atleast 1 digit");
        }
        if (specialCnt == 0) {
            System.out.println("Password must contain atleast 1 special character");
        }

        if (upperCnt >= 1 && lowerCnt >= 1 && digitCnt >= 1 && specialCnt >= 1) {
            return true;
        } else {
            return false;
        }
    }

}
